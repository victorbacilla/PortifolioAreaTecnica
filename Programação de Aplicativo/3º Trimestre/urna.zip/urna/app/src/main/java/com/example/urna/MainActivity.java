package com.example.urna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText cpf, idCandidato;
    ArrayList<String> confirmados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cpf = findViewById(R.id.cpf);
        idCandidato = findViewById(R.id.idCandidato);
    }
}