package cadastrodecarros;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class BdCarros {
    private static Connection connection;   
    public static Connection getConnection(){ // método que integra com o pgadmin
        if(connection == null){
            try{
                Class.forName("org.postgresql.Driver");// driver para postgresql (pgadmin)
                String host = "localhost";
                String port = "5432"; // a porta geralmente é essa
                String database = "CadastroCarros"; // escolhe o database
                String user = "postgres";
                String password = "postgres";//digitar a senha do seu banco
                String url = "jdbc:postgresql://"+host+":"+port+"/"+database;// concatenando strings
                connection = DriverManager.getConnection(url, user, password);           
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    } 
    public static void close(){
        if (connection == null){
            throw new RuntimeException("Nenhuma conexão aberta!");
        } else{
            try{
                connection.close();
            } catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
    
    
    public static void salvar (Carro carro){
        try{
            Connection con = BdCarros.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO carros (id, nome, modelo, ano, quilometragem, concessionariavendedora, valor) values(?, ?, ?, ?, ?, ?, ?)");
            ps.setInt(1, carro.getId());
            ps.setString(2, carro.getNome());
            ps.setString(3, carro.getModelo());
            ps.setInt(4, carro.getAno());
            ps.setLong(5, carro.getQuilometragem());
            ps.setLong(6, carro.getConcessionariaVendedora());
            ps.setFloat(7, carro.getValor());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public static void deleta(int id){
        try{
            Connection con = BdCarros.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete * FROM carro WHERE id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    public static void atualizaDados(long idNovo, String nomeNovo, String modeloNovo, int anoNovo, long quilometragemNova, long concessionariaVendedora, float valorNovo, long idAntigo){ // Insere primeiro o login e senha novos e depois o login antigo
        try {
            Connection con = BdConcessionarias.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE carros SET id = ?, nome = ?, modelo = ?, ano = ?, quilometragem = ?, concessionariavendedora = ?, valor = ? WHERE id = ?");
            ps.setLong(1, idNovo); // atualiza id
            ps.setString(2, nomeNovo); // atualiza nome
            ps.setString(3, modeloNovo); // atualiza modelo
            ps.setInt(4, anoNovo); // atualiza ano
            ps.setLong(5, quilometragemNova); // atualiza quilometragem
            ps.setLong(6, concessionariaVendedora); // atualiza concessionária vendedora
            ps.setFloat(7, valorNovo); // atualiza valor
            ps.setLong(8, idAntigo); // id do carro que vai ser atualizado
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }    
    
    public static Map visualizarTabela(String nomeTabela, String cnpj, String teste,String... atributos){ // entradas são o nome da tabela a ser alterada e suas colunas
        Hashtable<String, String> dict = new Hashtable<String, String>();
        try{ // ele vai tentar executar o que queremos, se não executar é um erro a ser tratado
            Connection con = BdUsuarios.getConnection(); // pega a connection
            PreparedStatement ps = con.prepareStatement("select "+teste+" from "+nomeTabela+" where concessionariavendedora = "+cnpj); // aqui é o código que se executa no pgadmin
            ResultSet rs = ps.executeQuery(); // executa query (que contém a instrução sql) e retorna o resultset rs
            String selectFrom = ""; // declara a string
            int x = 1;
            while(rs.next()){ // varrer as linhas uma a uma
                selectFrom = "";
                for(String i: atributos){ // checa primeiro o login, depois a senha, depois a idade e passa pra prox linha
                    selectFrom += " "+rs.getString(i);
                    //selectFrom = selectFrom +" - "+rs.getString(i); // aqui monta a estrutura que vamos printar no netbeans
                } // fecha o for
                dict.put(String.valueOf(x)  , selectFrom);
                x += 1;
                //selectFrom = selectFrom+"\n"; // pula para a próxima linha da tabela
            } // fecha o while
            System.out.println(selectFrom); // printa
            return dict;
        } catch (SQLException e){ // caso dê algum erro, aqui ele é tratado
            e.printStackTrace(); // trata o erro
        } // fecha o catch
        return dict;
    } // acaba o método
}