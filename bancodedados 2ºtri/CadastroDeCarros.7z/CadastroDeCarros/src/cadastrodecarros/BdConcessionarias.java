package cadastrodecarros;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Hashtable;
import javax.swing.DefaultComboBoxModel;

public class BdConcessionarias {
    private static Connection connection;   
    public static Connection getConnection(){ // método que integra com o pgadmin
        if(connection == null){
            try{
                Class.forName("org.postgresql.Driver");// driver para postgresql (pgadmin)
                String host = "localhost";
                String port = "5432"; // a porta geralmente é essa
                String database = "CadastroCarros"; // escolhe o database
                String user = "postgres";
                String password = "postgres";//digitar a senha do seu banco
                String url = "jdbc:postgresql://"+host+":"+port+"/"+database;// concatenando strings
                connection = DriverManager.getConnection(url, user, password);           
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    } 
    public static void close(){
        if (connection == null){
            throw new RuntimeException("Nenhuma conexão aberta!");
        } else{
            try{
                connection.close();
            } catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
    
    
    public static void salvar (Concessionaria concessionaria){
        try{
            Connection con = BdConcessionarias.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO concessionarias (cnpj, nome, anofundacao, avaliacao) values(?, ?, ?, ?)");
            ps.setLong(1, concessionaria.getCnpj());
            ps.setString(2, concessionaria.getNome());
            ps.setInt(3, concessionaria.getAnoFundacao());
            ps.setInt(4, concessionaria.getAvaliacao());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public static void deleta(long cnpj){
        try{
            Connection con = BdConcessionarias.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete * FROM concessionaria WHERE cnpj = ?");
            ps.setLong(1, cnpj);
            ps.executeUpdate();
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    public static void atualizaDados(long cnpjNovo, String nomeNovo, int anoFundacaoNovo, int avaliacaoNova, long cnpjAntigo){ // Insere primeiro o login e senha novos e depois o login antigo
        try {
            Connection con = BdConcessionarias.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE concessionarias SET cnpj = ?, nome = ?, anofundacao = ?, avaliacao = ? WHERE cnpj = ?");
            ps.setLong(1, cnpjNovo); // atualiza cnpj
            ps.setString(2, nomeNovo); // atualiza nome
            ps.setInt(3, anoFundacaoNovo); // atualiza ano de fundação
            ps.setInt(4, avaliacaoNova); // atualiza avaliação no sistema
            ps.setLong(5, cnpjAntigo); // cnpj da concessionária em que os dados serão atualizados
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }    
    
    public static DefaultComboBoxModel visualizarTabela(String nomeTabela, String... atributos){ // entradas são o nome da tabela a ser alterada e suas colunas
        try{ // ele vai tentar executar o que queremos, se não executar é um erro a ser tratado
            Connection con = BdUsuarios.getConnection(); // pega a connection
            PreparedStatement ps = con.prepareStatement("select cnpj from "+nomeTabela); // aqui é o código que se executa no pgadmin
            ResultSet rs = ps.executeQuery(); // executa query (que contém a instrução sql) e retorna o resultset rs
            String selectFrom = ""; // declara a string
            String[] errorSoon = new String[10];
            int x = 1;
            while(rs.next()){
                for(String i: atributos){ selectFrom = rs.getString(i); }
               errorSoon[x] = selectFrom;
               x += 1;
            }
            DefaultComboBoxModel model = new DefaultComboBoxModel(errorSoon);
            return model;
        } catch (SQLException e){ 
            e.printStackTrace();
        }
        String[] petStrings = {"ERROR"};
        DefaultComboBoxModel model = new DefaultComboBoxModel(petStrings);
        return model;
    } 
}