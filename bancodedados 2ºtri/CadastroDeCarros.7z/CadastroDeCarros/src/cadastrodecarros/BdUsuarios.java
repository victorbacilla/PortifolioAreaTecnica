package cadastrodecarros;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BdUsuarios {
    private static Connection connection;   
    public static Connection getConnection(){ // método que integra com o pgadmin
        if(connection == null){
            try{
                Class.forName("org.postgresql.Driver");// driver para postgresql (pgadmin)
                String host = "localhost";
                String port = "5432"; // a porta geralmente é essa
                String database = "CadastroCarros"; // escolhe o database
                String user = "postgres";
                String password = "postgres";//digitar a senha do seu banco
                String url = "jdbc:postgresql://"+host+":"+port+"/"+database;// concatenando strings
                connection = DriverManager.getConnection(url, user, password);           
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
   
    
    public static void close(){
        if (connection == null){
            throw new RuntimeException("Nenhuma conexão aberta!");
        } else{
            try{
                connection.close();
            } catch (SQLException e){
                e.printStackTrace();
            }
        }
    }
    
    
    public static boolean Login(String login, int senha, String tabela, String... atributos){
        try{
            Connection con = BdUsuarios.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM " + tabela);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                if (login.equals(rs.getString("Login")) && senha == Integer.parseInt(rs.getString("Senha"))){
                    return true;
                }
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    
    
    public static void salvar(Usuario usuario){
        try{
            Connection con = BdUsuarios.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO usuario (login, senha) values(?, ?)");
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getSenha());
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public static void deleta(String login){
        try{
            Connection con = BdUsuarios.getConnection();
            PreparedStatement ps = con.prepareStatement("Delete * FROM usuario WHERE login = ?");
            ps.setString(1, login);
            ps.executeUpdate();
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    
    public static void atualizaDados(String loginNovo, String senhaNova, String loginAntigo){ // Insere primeiro o login e senha novos e depois o login antigo
        try {
            Connection con = BdUsuarios.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE atualizaDados SET login = ?, senha = ? WHERE login = ?");
            ps.setString(1, loginNovo); // atualiza login
            ps.setString(2, senhaNova); // atualiza senha
            ps.setString(3, loginAntigo); // login antigo para definir o usuário a atualizar
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
    public static String visualizarTabela(String nomeTabela, String... atributos){ // entradas são o nome da tabela a ser alterada e suas colunas
        try{ // ele vai tentar executar o que queremos, se não executar é um erro a ser tratado
            Connection con = BdUsuarios.getConnection(); // pega a connection
            PreparedStatement ps = con.prepareStatement("select * from "+nomeTabela); // aqui é o código que se executa no pgadmin
            ResultSet rs = ps.executeQuery(); // executa query (que contém a instrução sql) e retorna o resultset rs
            String selectFrom = ""; // declara a string
            while(rs.next()){ // varrer as linhas uma a uma
                for(String i: atributos){ // checa primeiro o login, depois a senha, depois a idade e passa pra prox linha
                    selectFrom = selectFrom +" | "+rs.getString(i); // aqui monta a estrutura que vamos printar no netbeans
                } // fecha o for
                selectFrom = selectFrom+"\n"; // pula para a próxima linha da tabela
            } // fecha o while
            System.out.println(selectFrom); // printa
            return selectFrom;
        } catch (SQLException e){ // caso dê algum erro, aqui ele é tratado
            e.printStackTrace(); // trata o erro
        } // fecha o catch
        return "ERROR";
    } // acaba o método
}
