package cadastrodecarros;
public class CadastroDeCarros {

    public static void main(String[] args) {
        // BdCarros.atualizaDados(200, "Paliozão", "S", 2022, 0, 11122233300L, 100);
        // BdConcessionarias.atualizaDados(99977755512L, "Era do Gelo", 2018, 8, 0);
        Login telaLogin = new Login();
        telaLogin.setVisible(true);
    }    
}