package cadastrodecarros;
public class Carro {
    int id, ano; // para tabela carros
    String nome, modelo; // para tabela carros
    long quilometragem, concessionariaVendedora; // para tabela carros
    float valor;

    public Carro(int id, String nome, String modelo, int ano, long quilometragem, long concessionariaVendedora, float valor){
        this.id = id;
        this.nome = nome;
        this.modelo = modelo;
        this.ano = ano;
        this.quilometragem = quilometragem;
        this.concessionariaVendedora = concessionariaVendedora;
        this.valor = valor;
    }
 // ------------------- // --------------- //
 // ------------------- // --------------- //
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
 // ------------------- // --------------- //
 // ------------------- // --------------- //    
    public int getAno() {
        return ano;
    }
    public void setAno(int ano) {
        this.ano = ano;
    }
 // ------------------- // --------------- //
 // ------------------- // --------------- //
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
 // ------------------- // --------------- //    
 // ------------------- // --------------- //
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
 // ------------------- // --------------- //    
 // ------------------- // --------------- //
    public long getQuilometragem() {
        return quilometragem;
    }
    public void setQuilometragem(long quilometragem) {
        this.quilometragem = quilometragem;
    }
 // ------------------- // --------------- //    
 // ------------------- // --------------- //
    public long getConcessionariaVendedora() {
        return concessionariaVendedora;
    }
    public void setConcessionariaVendedora(long concessionariaVendedora) {
        this.concessionariaVendedora = concessionariaVendedora;
    } 
 // ------------------- // --------------- //
 // ------------------- // --------------- //
    public float getValor(){
        return valor;
    }
    public void setValor (float valor){
        this.valor = valor;
    }    
}