package cadastrodecarros;
public class Concessionaria {
    long cnpj;
    String nome;
    int anoFundacao, avaliacao;
    
    public Concessionaria(long cnpj, String nome, int anoFundacao, int avaliacao){
        this.cnpj = cnpj;
        this.nome = nome;
        this.anoFundacao = anoFundacao;
        this.avaliacao = avaliacao;
    }

    public long getCnpj() {
        return cnpj;
    }
    public void setCnpj(long cnpj) {
        this.cnpj = cnpj;
    }
    

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    

    public int getAnoFundacao() {
        return anoFundacao;
    }
    public void setAnoFundacao(int anoFundacao) {
        this.anoFundacao = anoFundacao;
    }

    
    public int getAvaliacao() {
        return avaliacao;
    }
    public void setAvaliacao(int avaliacao) {
        this.avaliacao = avaliacao;
    }  
}